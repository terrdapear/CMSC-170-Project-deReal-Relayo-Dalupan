CMSC 170 Project Milestone 2 - CATgpt

To run:
1. Copy the Data folder from our repository next to main.py:
   https://github.com/terrdapear/CMSC-170-Project-deReal-Relayo-Dalupan
2. Run: python3 main.py

Data loading and preprocessing: scripts/preprocess.py, scripts/bow.py, scripts/count.py
Naive Bayes: scripts/NB.py
KNN: scripts/KNN.py
Perceptron: scripts/perceptron.py
Evaluation metrics: scripts/metrics.py
Parquet conversion and file splitting, run once: helper_scripts/parq_to_txt.py, RA/split.py
